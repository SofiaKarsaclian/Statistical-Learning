## Filtered Data

|   |variable                | correlation|
## Filtered Data

|:--|:-----------------------|-----------:|
## Filtered Data

|2  |texture_mean            |   0.4151853|
## Filtered Data

|5  |smoothness_mean         |   0.3585600|
## Filtered Data

|9  |symmetry_mean           |   0.3304986|
## Filtered Data

|10 |fractal_dimension_mean  |  -0.0128376|
## Filtered Data

|12 |texture_se              |  -0.0083033|
## Filtered Data

|15 |smoothness_se           |  -0.0670160|
## Filtered Data

|16 |compactness_se          |   0.2929992|
## Filtered Data

|17 |concavity_se            |   0.2537298|
## Filtered Data

|18 |concave.points_se       |   0.4080423|
## Filtered Data

|19 |symmetry_se             |  -0.0065218|
## Filtered Data

|20 |fractal_dimension_se    |   0.0779724|
## Filtered Data

|22 |texture_worst           |   0.4569028|
## Filtered Data

|25 |smoothness_worst        |   0.4214649|
## Filtered Data

|29 |symmetry_worst          |   0.4162943|
## Filtered Data

|30 |fractal_dimension_worst |   0.3238722|
